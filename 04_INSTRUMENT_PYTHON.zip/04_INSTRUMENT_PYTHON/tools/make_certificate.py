"""make_certificate.py — regenerate the XRF-PORTABLE verification certificate.

Pulls the sealed QA battery report (QCBATTERY/battery_report.json) and the
live receipt chain (SESSION_CHAIN.jsonl), verifies the chain, and emits
DOCUMENTS/certificate_<date>.md — the vendor-analog calibration/verification
certificate, regenerated per battery run.
"""
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from sniffer import receipt as receipt_mod  # noqa: E402
from sniffer.sniffer import SNIFFER_VERSION, ENGINE_VERSION  # noqa: E402

BATTERY = os.path.join(ROOT, "QCBATTERY", "battery_report.json")
CHAIN = os.path.join(ROOT, "SESSION_CHAIN.jsonl")
OUT_DIR = os.path.join(ROOT, "DOCUMENTS")


def main() -> int:
    with open(BATTERY, encoding="utf-8") as f:
        rep = json.load(f)

    chain_ok = receipt_mod.verify_chain(CHAIN)
    last, n = None, 0
    with open(CHAIN, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                n += 1
                last = json.loads(line)
    last_seq = last.get("seq") if isinstance(last, dict) else "?"
    last_hash = (last.get("hash") or "")[:16] if isinstance(last, dict) else "?"

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    dest = os.path.join(OUT_DIR, f"certificate_{stamp}.md")
    lines = [
        "# XRF-PORTABLE — VERIFICATION CERTIFICATE",
        "",
        f"**Issued:** {stamp} · **Instrument:** code-based XRF + coil (attached head)",
        f"**Versions:** {rep.get('model', {}).get('version') or (f'sniffer-{SNIFFER_VERSION} + engine-{ENGINE_VERSION}')} · **Calibration id:** {rep['model']['calibration_id']}",
        f"**Seed:** {rep.get('seed')} (logged per item: {list(rep.get('item_seeds', {}).items())})",
        "",
        "## 1. Verification of the receipt chain",
        "",
        f"- chain length: **{n} receipts** (append-only, `SESSION_CHAIN.jsonl`)",
        f"- latest: seq **{last_seq}**, hash `{last_hash}…`",
        f"- verify_chain verdict: **{'PASS' if getattr(chain_ok, 'ok', chain_ok) else chain_ok}**",
        "",
        "## 2. The QA battery (vendor daily-check protocol, rebuilt in code)",
        "",
        f"- items: **{rep['n_items']}/{rep['n_passed']} PASSED** — {'ALL GREEN' if rep.get('ok') else 'ATTENTION: ' + str(rep.get('failed'))}",
        "",
        "| item | vendor analog | verdict |",
        "|---|---|---|",
    ]
    for item in rep["items"]:
        name = item.get("item", "?")
        analog = item.get("vendor_analog", "—")
        verdict = "PASS" if item.get("ok") else "FAIL"
        lines.append(f"| {name} | {analog} | {verdict} |")

    lines += [
        "",
        "## 3. Standing certifications (whole chain)",
        "",
        "- per-element law audit: **71/71 PASS** (`AUDIT/per_element_audit.json`)",
        "- external cross-check (xraylib + PyMca, live pulls, check classes labeled X1-X3 cross-edition / X4-X5 same-source guards): **5/5 PASS**",
        "- test suite: **226 passed**",
        "- falsifier register: F2 enforced per-read (≤10⁻¹²); F1 run in-code (seq 10: PASS with spoken deviation, PROOF/06); F3 run in-code (seq 11: PASS, exit 0 — the ground bitwise rung-invariant at the invariant, crossings registered, EM→mass margin 11.3 orders, PROOF/07); engineering round 2 confirmed (seq 12: X4/X5 labels, M-8); F6 runnable (tissue channel G3)",
        "",
        "## 4. How to re-verify (independent)",
        "",
        "```powershell",
        "python -m pytest engine\\tests sniffer\\tests -q",
        f"python -m sniffer verify QCBATTERY\\battery.receipt.json --chain SESSION_CHAIN.jsonl",
        "python tools\\make_certificate.py    # regenerate this certificate",
        "```",
        "",
        "*Certification model: each item's measured/reference/tolerance rows are inside `QCBATTERY/battery_report.json`; this certificate binds that report by its chain placement, so the report cannot drift from the certificate without breaking a signature.*",
        "*Issued by the instrument, not by a person — per the provenance discipline (PAPERS/paper_5).*",
    ]
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(dest, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("certificate ->", dest)
    print(f"chain: {n} receipts, latest seq {last_seq} ({last_hash}); "
          f"battery {rep['n_passed']}/{rep['n_items']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
