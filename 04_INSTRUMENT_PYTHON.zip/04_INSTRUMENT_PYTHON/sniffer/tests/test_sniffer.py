"""The sniff pipeline: recovery, line ID, uncertainty, minerals, provenance."""
from __future__ import annotations

import numpy as np
import pytest

import engine
from engine import elements as eng_elements
from engine import forward as eng_forward
from engine import simulate as eng_simulate

from sniffer.sniffer import SniffError, default_elements, resolve_detector, sniff
from sniffer.spectrum import Spectrum, SpectrumValidationError


@pytest.fixture(scope="module")
def synthetic():
    sample = eng_simulate.crustal_dust_sample(30.0)
    excitation = eng_forward.Excitation.tube(40.0, "Rh", total_flux=1e10)
    engine_spec = eng_simulate.simulate(
        sample, excitation, live_time_s=300.0, seed=20261031, air_path_cm=2.0)
    spec = Spectrum.from_engine(engine_spec, provenance="simulated")
    spec.flow_lpm = 16.7
    spec.duration_min = 1440.0
    spec.filter_area_cm2 = 11.3
    spec.sample_id = "crustal dust 30 ug/m3"
    report = sniff(spec)
    return sample, spec, report


def _rows(report):
    return {r["symbol"]: r for r in report.elements}


def test_recovery_within_engine_stated_error(synthetic):
    sample, _, report = synthetic
    rows = _rows(report)
    truth = {eng_elements.BY_Z[z].symbol: float(v * 1e6)
             for z, v in sample.areal.items()}
    target = ["Mg", "Al", "Si", "K", "Ca", "Fe"]
    rels = []
    for symbol in target:
        assert rows[symbol]["detection_flag"] == "detected", symbol
        rel = (rows[symbol]["areal_ug_cm2"] - truth[symbol]) / truth[symbol]
        rels.append(rel)
        # engine README: median 0.9 %, p90 10 %, max 18 %; allow 20 %
        assert abs(rel) <= 0.20, (symbol, rel)
    assert float(np.median(np.abs(rels))) <= 0.05


def test_no_spurious_detections(synthetic):
    _, _, report = synthetic
    detected = {r["symbol"] for r in report.elements
                if r["detection_flag"] == "detected"}
    assert detected == {"Mg", "Al", "Si", "K", "Ca", "Fe"}


def test_na_is_not_quantified_below_the_window(synthetic):
    _, _, report = synthetic
    na = _rows(report)["Na"]
    assert na["detection_flag"] == "not_quantified"
    assert na["quantified"] is False
    assert "no line" in na["note"]


def test_report_provenance_and_model(synthetic):
    _, _, report = synthetic
    assert report.provenance == "simulated"
    assert report.model["physics"] == "classical"
    assert report.model["version"].startswith("sniffer-")
    assert report.model["calibration_id"]
    assert report.model["label"] == "[MODEL]"
    assert report.spectrum["provenance"] == "simulated"
    assert report.spectrum["sha256"]


def test_fit_quality_and_structure(synthetic):
    _, _, report = synthetic
    assert report.fit["relative_residual"] < 0.05
    assert report.fit["quality"] == "good"
    assert report.fit["n_peaks"] >= 5
    assert report.fit["n_elements_detected"] == 6
    assert report.peaks
    assert report.lines


def test_elements_carry_uncertainty_mdl_and_flag(synthetic):
    _, _, report = synthetic
    for row in report.elements:
        assert row["detection_flag"] in ("detected", "below_mdl", "not_quantified")
        if row["detection_flag"] == "detected":
            assert row["areal_ug_cm2"] > 0
            assert row["mdl_ug_cm2"] is not None and row["mdl_ug_cm2"] > 0
            assert row["sigma_ug_cm2"] is not None and row["sigma_ug_cm2"] > 0
            assert row["systematic_ug_cm2"] > 0
            assert row["total_sigma_ug_cm2"] > 0
            assert row["areal_ug_cm2"] >= report.fit["reporting_floor_ug_cm2"]


def test_peak_line_matching_residuals(synthetic):
    _, _, report = synthetic
    by_center = {round(p["center_ev"]): p for p in report.peaks}
    si = min(report.peaks, key=lambda p: abs(p["center_ev"] - 1739.8))
    assert si["best_line"]["element"] == "Si"
    assert si["best_line"]["line"] == "Ka1"
    assert abs(si["residual_ev"]) < 5.0
    fe = min(report.peaks, key=lambda p: abs(p["center_ev"] - 6405.2))
    assert fe["best_line"]["element"] == "Fe"
    assert fe["best_line"]["line"] == "Ka1"
    assert abs(fe["residual_ev"]) < 10.0
    assert all(p["center_ev"] >= report.fit["peak_min_ev"] for p in report.peaks)


def test_mineral_apportionment_conserves_every_element(synthetic):
    _, _, report = synthetic
    minerals = report.minerals
    assert minerals["conservation"]["apportioned_equals_measured"] is True
    assert abs(minerals["conservation"]["difference_ug_cm2"]) < 1e-9
    row_sum = sum(r["element_mass_ug_cm2"] for r in minerals["rows"])
    assert abs(row_sum - minerals["measured_element_mass_ug_cm2"]) < 1e-6
    assert minerals["rows"]
    assert any(r["name"] == "quartz" for r in minerals["rows"])
    assert "unmix" in minerals and "closure" in minerals["unmix"]


def test_calibration_id_override(synthetic):
    _, spec, _ = synthetic
    report = sniff(spec, calibration_id="TEST-CAL-001")
    assert report.model["calibration_id"] == "TEST-CAL-001"


def test_explicit_element_set_and_strict_mode(synthetic):
    _, spec, _ = synthetic
    report = sniff(spec, elements=[14, 26], add_peak_elements=False)
    detected = {r["symbol"] for r in report.elements
                if r["detection_flag"] == "detected"}
    assert detected <= {"Si", "Fe"}
    assert "Al" not in detected


def test_refuses_to_upgrade_simulated_to_measured(synthetic):
    _, spec, _ = synthetic
    with pytest.raises(SniffError):
        sniff(spec, provenance="measured")


def test_invalid_spectrum_raises():
    spec = Spectrum(np.array([0.0, 10.0, 5.0]), np.array([1.0, 2.0, 3.0]),
                    live_time_s=10.0)
    with pytest.raises(SpectrumValidationError):
        sniff(spec)


def test_default_elements_are_the_mineral_visible_set():
    symbols = {eng_elements.BY_Z[z].symbol for z in default_elements()}
    assert {"Mg", "Al", "Si", "S", "Cl", "K", "Ca", "Ti", "Mn", "Fe"} <= symbols
    assert not ({"H", "C", "N", "O"} & symbols)


def test_detector_aliases():
    assert resolve_detector("SDD").name == "SDD-25mm2"
    assert resolve_detector("SDD-25mm2").name == "SDD-25mm2"
    assert resolve_detector("SI_PIN_7").name == "SiPIN-7mm2"
    with pytest.raises(SniffError):
        resolve_detector("not-a-detector")
